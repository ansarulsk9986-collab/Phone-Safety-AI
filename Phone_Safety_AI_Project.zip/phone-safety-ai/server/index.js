import "dotenv/config";
import express from "express";
import cors from "cors";
import OpenAI from "openai";
import { agents, chooseAgent } from "./agents.js";

const app = express();
app.use(cors({ origin: process.env.ALLOWED_ORIGIN?.split(",") || true }));
app.use(express.json({ limit: "7mb" }));

const client = process.env.OPENAI_API_KEY
  ? new OpenAI({ apiKey: process.env.OPENAI_API_KEY })
  : null;

app.get("/api/health", (_req, res) => {
  res.json({ ok: true, aiConnected: Boolean(client), app: "SUPER AI" });
});

app.get("/api/agents", (_req, res) => {
  res.json(Object.entries(agents).map(([id, agent]) => ({
    id, name: agent.name, role: agent.role, color: agent.color
  })));
});

app.post("/api/chat", async (req, res) => {
  const { message, agentId = "auto", history = [], imageData = null } = req.body || {};
  if (typeof message !== "string" || !message.trim() || message.length > 6000) {
    return res.status(400).json({ error: "Enter a message up to 6,000 characters." });
  }

  const selectedId = agentId === "auto"
    ? (imageData ? "vision" : chooseAgent(message))
    : agentId;
  const agent = agents[selectedId];
  if (!agent) return res.status(400).json({ error: "Unknown assistant." });

  if (!client) {
    return res.status(503).json({
      error: "AI is not connected yet. Add your API key to the server .env file, then restart SUPER AI."
    });
  }

  if (imageData !== null) {
    const validImage = typeof imageData === "string" &&
      /^data:image\/(png|jpeg|webp);base64,[A-Za-z0-9+/=]+$/.test(imageData) &&
      imageData.length <= 6_500_000;
    if (!validImage) return res.status(400).json({ error: "Upload a PNG, JPEG, or WebP image under 5 MB." });
    if (selectedId !== "vision") return res.status(400).json({ error: "Choose VISION to analyze an image." });
  }

  const safeHistory = Array.isArray(history)
    ? history.slice(-8).filter(item =>
        item && ["user", "assistant"].includes(item.role) &&
        typeof item.content === "string"
      ).map(item => ({ role: item.role, content: item.content.slice(0, 3000) }))
    : [];

  try {
    const response = await client.responses.create({
      model: process.env.OPENAI_MODEL || "gpt-5.5",
      instructions: `${agent.instructions}\nYou are one member of SUPER AI. Your role is ${agent.role}.`,
      input: [
        ...safeHistory,
        {
          role: "user",
          content: imageData
            ? [
                { type: "input_text", text: message.trim() || "Please describe this image." },
                { type: "input_image", image_url: imageData }
              ]
            : message.trim()
        }
      ]
    });
    res.json({
      agentId: selectedId,
      agentName: agent.name,
      reply: response.output_text || "I couldn't produce a text response. Please try again."
    });
  } catch (error) {
    console.error("AI request failed:", error?.message || error);
    res.status(502).json({ error: "The AI service could not complete that request. Check the server log and try again." });
  }
});

const port = Number(process.env.PORT || 3001);
app.listen(port, () => console.log(`SUPER AI server running at http://localhost:${port}`));
