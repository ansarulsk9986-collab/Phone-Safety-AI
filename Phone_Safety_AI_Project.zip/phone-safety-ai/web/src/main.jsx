import React, { useEffect, useMemo, useRef, useState } from "react";
import { createRoot } from "react-dom/client";
import {
  Activity, AudioLines, Bot, ChevronDown, CircleHelp, Cpu, LockKeyhole,
  Mic, MicOff, Send, ShieldCheck, Sparkles, Volume2, VolumeX, Zap, Eye, ImagePlus, X
} from "lucide-react";
import "./style.css";

const API = import.meta.env.VITE_API_URL || "";
const agents = [
  { id: "auto", name: "SUPER AI", role: "Automatic specialist routing", icon: Sparkles, color: "multi" },
  { id: "jarvis", name: "JARVIS", role: "Main assistant", icon: Bot, color: "blue" },
  { id: "friday", name: "FRIDAY", role: "Research & learning", icon: Cpu, color: "violet" },
  { id: "camman", name: "CAMMAN", role: "Communication", icon: AudioLines, color: "cyan" },
  { id: "ultron", name: "ULTRON", role: "Defensive security", icon: ShieldCheck, color: "red" },
  { id: "vision", name: "VISION", role: "Image understanding", icon: Eye, color: "green" },
  { id: "edith", name: "EDITH", role: "Digital organizer", icon: Zap, color: "gold" }
];
const voices = {
  jarvis: { pitch: .92, rate: .98, preferred: ["Daniel", "Google UK English Male"] },
  friday: { pitch: 1.18, rate: 1.02, preferred: ["Samantha", "Google UK English Female"] },
  camman: { pitch: 1.08, rate: 1.08, preferred: ["Google US English"] },
  ultron: { pitch: .78, rate: .94, preferred: ["Alex", "Google UK English Male"] },
  edith: { pitch: 1, rate: .9, preferred: ["Karen", "Google US English"] },
  vision: { pitch: 1.12, rate: 1, preferred: ["Google US English"] }
};

function App() {
  const [active, setActive] = useState("auto");
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");
  const [imageData, setImageData] = useState(null);
  const [imageName, setImageName] = useState("");
  const fileInputRef = useRef(null);
  const [busy, setBusy] = useState(false);
  const [voiceOn, setVoiceOn] = useState(true);
  const [listening, setListening] = useState(false);
  const [health, setHealth] = useState(null);
  const endRef = useRef(null);
  const recognitionRef = useRef(null);

  const current = agents.find(a => a.id === active) || agents[0];
  const chatHistory = useMemo(() => messages.slice(-8).map(m => ({
    role: m.role, content: m.content
  })), [messages]);

  useEffect(() => {
    fetch(`${API}/api/health`).then(r => r.json()).then(setHealth).catch(() => setHealth({ ok: false, aiConnected: false }));
  }, []);
  useEffect(() => endRef.current?.scrollIntoView({ behavior: "smooth" }), [messages, busy]);

  function speak(text, agentId) {
    if (!voiceOn || !("speechSynthesis" in window)) return;
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    const config = voices[agentId] || voices.jarvis;
    utterance.pitch = config.pitch;
    utterance.rate = config.rate;
    const available = window.speechSynthesis.getVoices();
    const voice = config.preferred.map(name => available.find(v => v.name.includes(name))).find(Boolean)
      || available.find(v => v.lang?.startsWith("en"));
    if (voice) utterance.voice = voice;
    window.speechSynthesis.speak(utterance);
  }

  async function sendMessage(event) {
    event?.preventDefault();
    const text = input.trim();
    if ((!text && !imageData) || busy) return;
    const userContent = imageData ? `${text || "Please describe this image."} [Image: ${imageName}]` : text;
    const next = [...messages, { role: "user", content: userContent }];
    setMessages(next);
    setInput("");
    setBusy(true);
    try {
      const response = await fetch(`${API}/api/chat`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: text || "Please describe this image.", agentId: imageData ? "vision" : active, history: chatHistory, imageData })
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "Request failed.");
      const answer = { role: "assistant", content: data.reply, agentId: data.agentId, agentName: data.agentName };
      setMessages(prev => [...prev, answer]);
      speak(data.reply, data.agentId);
      setImageData(null);
      setImageName("");
    } catch (error) {
      setMessages(prev => [...prev, { role: "assistant", content: `Connection notice: ${error.message}`, agentName: "SYSTEM" }]);
    } finally {
      setBusy(false);
    }
  }

  function chooseImage(event) {
    const file = event.target.files?.[0];
    if (!file) return;
    if (!["image/png", "image/jpeg", "image/webp"].includes(file.type) || file.size > 5 * 1024 * 1024) {
      setMessages(prev => [...prev, { role: "assistant", content: "Please choose a PNG, JPEG, or WebP image under 5 MB.", agentName: "SYSTEM" }]);
      event.target.value = "";
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      setImageData(reader.result);
      setImageName(file.name);
      setActive("vision");
    };
    reader.readAsDataURL(file);
    event.target.value = "";
  }

  function startListening() {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRecognition) {
      setMessages(prev => [...prev, { role: "assistant", content: "Voice input is not supported in this browser. You can still type your message.", agentName: "SYSTEM" }]);
      return;
    }
    const recognition = new SpeechRecognition();
    recognition.lang = navigator.language || "en-US";
    recognition.interimResults = false;
    recognition.onresult = e => setInput(e.results[0][0].transcript);
    recognition.onend = () => setListening(false);
    recognition.onerror = () => setListening(false);
    recognitionRef.current = recognition;
    setListening(true);
    recognition.start();
  }

  return <div className="app-shell">
    <aside className="sidebar">
      <div className="brand"><div className="brand-mark"><ShieldCheck size={23}/></div><div><b>PHONE SAFETY AI</b><small>SIX-AGENT INTELLIGENCE</small></div></div>
      <div className="side-label">YOUR AI NETWORK</div>
      <nav className="agent-list">
        {agents.map(agent => {
          const Icon = agent.icon;
          return <button key={agent.id} className={`agent-button ${active === agent.id ? "selected" : ""}`} onClick={() => setActive(agent.id)}>
            <span className={`agent-icon ${agent.color}`}><Icon size={18}/></span>
            <span className="agent-copy"><b>{agent.name}</b><small>{agent.role}</small></span>
            {active === agent.id && <span className="active-dot"/>}
          </button>;
        })}
      </nav>
      <div className="sidebar-bottom">
        <div className="secure-note"><LockKeyhole size={16}/><span>Private API key stays on server</span></div>
        <div className="version">PHONE SAFETY AI · STARTER 1.1</div>
      </div>
    </aside>

    <main className="main-panel">
      <header className="topbar">
        <div className="mobile-brand"><ShieldCheck size={20}/> PHONE SAFETY AI</div>
        <div className="system-status"><span className={`status-light ${health?.aiConnected ? "online" : ""}`}/>{health?.aiConnected ? "AI CORE CONNECTED" : "SETUP REQUIRED"}</div>
        <button className={`sound-toggle ${voiceOn ? "on" : ""}`} onClick={() => { setVoiceOn(!voiceOn); if (voiceOn) window.speechSynthesis?.cancel(); }}>
          {voiceOn ? <Volume2 size={16}/> : <VolumeX size={16}/>} <span>{voiceOn ? "VOICE ON" : "VOICE OFF"}</span>
        </button>
      </header>

      <section className="workspace">
        <div className="hero">
          <div className="eyebrow"><span className="pulse"/> CENTRAL INTELLIGENCE CORE</div>
          <h1>Think beyond<br/><span>the ordinary.</span></h1>
          <p>One central brain. Six specialist AIs. Ready to work together.</p>
          <div className="core-orbit"><div className="orbit orbit-one"/><div className="orbit orbit-two"/><div className="core"><Cpu size={35}/><span>AI</span></div><i className="node n1"/><i className="node n2"/><i className="node n3"/><i className="node n4"/></div>
        </div>

        <div className="chat-area">
          <div className="chat-heading">
            <div><div className="eyebrow">ACTIVE ASSISTANT</div><h2>{current.name}</h2><p>{current.role}</p></div>
            <div className="mode-chip"><Activity size={14}/> {active === "auto" ? "AUTO ROUTING" : "SPECIALIST MODE"}</div>
          </div>
          <div className="messages">
            {messages.length === 0 && <div className="welcome-card">
              <div className="welcome-icon"><Sparkles size={22}/></div>
              <h3>How can I help you today?</h3>
              <p>Ask a question, choose a specialist, or use your microphone.</p>
              <div className="suggestions">
                {["Explain how AI works", "Help me stay safe online", "Translate a sentence"].map(s => <button key={s} onClick={() => setInput(s)}>{s}<span>↗</span></button>)}
              </div>
            </div>}
            {messages.map((m, i) => <div key={i} className={`message ${m.role}`}>
              <div className="message-avatar">{m.role === "user" ? "YOU" : <Sparkles size={15}/>}</div>
              <div className="message-body"><div className="message-name">{m.role === "user" ? "YOU" : (m.agentName || "SUPER AI")}</div><p>{m.content}</p></div>
            </div>)}
            {busy && <div className="thinking"><span/><span/><span/> SUPER AI IS THINKING</div>}
            <div ref={endRef}/>
          </div>
          {imageData && <div className="image-attachment"><img src={imageData} alt="Selected upload preview"/><span>{imageName}</span><button type="button" onClick={() => { setImageData(null); setImageName(""); }} aria-label="Remove image"><X size={15}/></button></div>}
          <form className="composer" onSubmit={sendMessage}>
            <input value={input} onChange={e => setInput(e.target.value)} placeholder={`Message ${current.name}...`} maxLength={6000}/>
            <input ref={fileInputRef} type="file" accept="image/png,image/jpeg,image/webp" hidden onChange={chooseImage}/>
            <button type="button" className="mic-button" onClick={() => fileInputRef.current?.click()} title="Upload image"><ImagePlus size={18}/></button>
            <button type="button" className={`mic-button ${listening ? "recording" : ""}`} onClick={listening ? () => recognitionRef.current?.stop() : startListening} title="Voice input">{listening ? <MicOff size={18}/> : <Mic size={18}/>}</button>
            <button className="send-button" type="submit" disabled={(!input.trim() && !imageData) || busy}><Send size={17}/></button>
          </form>
          <div className="composer-foot"><span><LockKeyhole size={12}/> Messages are sent to your configured AI provider.</span><span>{input.length}/6000</span></div>
        </div>
      </section>
      <footer><span>PHONE SAFETY AI</span><span>SIX SPECIALISTS · ONE MISSION</span><span>BUILT FOR RESPONSIBLE ASSISTANCE</span></footer>
    </main>
  </div>;
}

createRoot(document.getElementById("root")).render(<App/>);
