# Phone Safety AI — Android + Website starter

Phone Safety AI is a starter project with one central chat UI and six specialist assistant personas:
- **JARVIS** — everyday/main assistant
- **FRIDAY** — research, learning, and coding explanations
- **CAMMAN** — translation and communication
- **VISION** — user-uploaded image understanding
- **ULTRON** — defensive digital safety
- **EDITH** — digital organization

The web app is also packaged for Android using Capacitor. Both clients use the same Express backend.

## What works in this starter
- Specialist selection and simple automatic routing
- Separate system instructions/personas for each specialist
- AI chat through the OpenAI Responses API
- PNG/JPEG/WebP image upload to VISION (up to 5 MB)
- Browser speech-to-text where supported
- Browser text-to-speech with different pitch/rate and preferred voice choices per assistant
- Responsive website layout suitable for mobile and desktop
- Android project generation through Capacitor

## What is not included yet
- This is a starter project, not a published app or APK.
- No automatic device control, live camera access, contacts, notifications, or file access is enabled. VISION only analyzes images the user deliberately uploads.
- Browser speech voices depend on the voices installed on the device; pitch/rate differences are fallbacks, not guaranteed unique human voices.
- The AI needs an API key and internet access. API usage may incur charges according to the provider's account and pricing.
- The simple automatic router uses keywords. It is not a separate super-intelligent model.

## Requirements
- Node.js 20 or newer
- npm
- An OpenAI API key for live AI responses
- Android Studio only if you want to build/install the Android app

## 1. Install
Open a terminal in this project folder:

```bash
npm install
```

## 2. Configure the AI backend
Copy `.env.example` to `.env`, then put your API key in `.env`:

```env
OPENAI_API_KEY=your_key_here
OPENAI_MODEL=gpt-5.5
PORT=3001
```

Never put the API key in `web/src`, a public website, GitHub, or the Android app. Keep it only on the backend server. The official JavaScript SDK uses the Responses API.

## 3. Run website and backend
```bash
npm run dev
```
- Website: http://localhost:5173
- Backend: http://localhost:3001/api/health

If the website is hosted separately from the backend, set `VITE_API_URL` to the backend's HTTPS URL before building. Configure the backend's `ALLOWED_ORIGIN` to your website origin in production.

## 4. Build the website
```bash
npm run build
```
The production website is created in `dist/`.

## 5. Create the Android project
Install Android Studio and its Android SDK, then run:

```bash
npm run android:add
npm run android:sync
npm run android:open
```

In Android Studio, let Gradle finish syncing, then use **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

For a real Android phone, the app must reach your deployed backend over HTTPS. Do not use `localhost` in the Android app for a remote backend. Set `VITE_API_URL` to your deployed backend URL, then rebuild and run `npm run android:sync`.

## Architecture

```text
Website (Vite + React) ─┐
                        ├── Express API ── OpenAI Responses API
Android (Capacitor) ────┘       |
                                └── JARVIS / FRIDAY / CAMMAN / ULTRON / VISION / EDITH prompts
```

## Safety and privacy notes
- ULTRON is restricted to defensive security guidance.
- The app does not secretly monitor or control a device.
- Do not add features that read private content or take actions without clear permission.
- Add authentication, request limits, HTTPS, and suitable data-retention controls before public deployment.
- Do not share your API key with anyone. If it is exposed, revoke it and create a replacement.
